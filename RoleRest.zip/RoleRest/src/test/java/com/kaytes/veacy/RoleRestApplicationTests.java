package com.kaytes.veacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = RoleRestApplication.class)
class RoleRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
